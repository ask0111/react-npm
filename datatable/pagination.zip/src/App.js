import logo from './logo.svg';
import './App.css';
import DataTable from './components/datatables/DataTable';
import DataTables from './components/datatablecomponets/DataTables';
import TableWrapper from './components/datatables/DataTable';

function App() {
  return (
    <div className="App">
    {/* <DataTables /> */}
    <TableWrapper />
    </div>
  );
}

export default App;
